from django.contrib import admin
from .models import Evidence, Witness, Battle

admin.site.register(Evidence)
admin.site.register(Witness)
admin.site.register(Battle)
